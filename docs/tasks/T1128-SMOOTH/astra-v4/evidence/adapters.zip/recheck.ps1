$ErrorActionPreference = 'Stop'
$evidence = Join-Path $PSScriptRoot 'evidence'
$observed = [System.Collections.Generic.SortedSet[int]]::new()
foreach ($file in (Get-ChildItem -LiteralPath $evidence -Filter '*.stdout.txt' -File)) {
    foreach ($line in (Get-Content -Encoding utf8 -LiteralPath $file.FullName)) {
        if ($line -match '^CLEANUP (.+)') {
            $cleanup = $Matches[1] | ConvertFrom-Json
            foreach ($idValue in @($cleanup.browserPid, $cleanup.pid)) {
                if ($idValue) { [void]$observed.Add([int]$idValue) }
            }
        }
        if ($line -match '^\s*cleanup \| browser pid=(\d+)') {
            [void]$observed.Add([int]$Matches[1])
            foreach ($set in [regex]::Matches($line, '(?:收尾前|主进程结束后残留|逐 PID 结束|复查仍存活)=([0-9,]+)')) {
                foreach ($item in $set.Groups[1].Value.Split(',')) {
                    [void]$observed.Add([int]$item)
                }
            }
        }
    }
}
if ($observed.Count -lt 5) { throw 'Missing browser process evidence' }
Write-Output "Get-Process -Id per observed PID at $([DateTime]::UtcNow.ToString('o'))"
foreach ($browserProcessId in $observed) {
    $live = Get-Process -Id $browserProcessId -ErrorAction SilentlyContinue
    if ($live) {
        Write-Output "PID=$browserProcessId PRESENT name=$($live.ProcessName) start=$($live.StartTime.ToUniversalTime().ToString('o'))"
    } else {
        Write-Output "PID=$browserProcessId ABSENT"
    }
}
