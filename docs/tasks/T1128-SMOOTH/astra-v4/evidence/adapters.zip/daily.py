"""Build private Git history and replay daily gates entirely offline."""
from run import BASE, FILES, FIX, HERE, OUT, ROOT, check, data, data_parts, digest, git, invoke, normalize, save, suite, ux
import json
import re
import shutil
import sys

def fgit(label, *args):
    return check(label, ["git", "-c", "core.hooksPath=NUL", "-c", "commit.gpgsign=false",
        "-c", "user.name=A4 fixture", "-c", "user.email=a4@example.invalid", *args], FIX)

def result(name):
    return json.loads((OUT / (name + ".json")).read_text(encoding="utf-8"))

def source(name, code, ci=True):
    run = suite(name, "source", FIX, *(["--ci"] if ci else []))
    assert run.returncode == code, name
    return {c["name"]: c for c in result(name)["checks"]}

def prep(name, target):
    head = git("rev-parse", "HEAD", cwd=FIX).decode().strip()
    check(name, ["node", "tests/smooth/prepare-ci-ux-baseline.mjs", head, target], FIX)

def make_fixture():
    assert not FIX.exists()
    check("clone-fixture", ["git", "clone", "--shared", "--no-checkout", str(ROOT), str(FIX)])
    fgit("remove-local-origin", "remote", "remove", "origin")
    fgit("select-initial-parent", "switch", "--detach", BASE + "^")
    for name in FILES:
        if name not in ("index.html", ".github/workflows/daily_thoradar.yml", "tests/aicls/lib.mjs"):
            (FIX/name).parent.mkdir(exist_ok=True, parents=True)
            shutil.copyfile(ROOT/name, FIX/name)
    # The historical edition uses exactly the old data contract, with the release candidate shell.
    before, current_block, after = data_parts(normalize((ROOT/"index.html").read_bytes()))
    _, old_block, _ = data_parts(git("show", BASE+"^:index.html"))
    marker = b'<meta name="a4-parent-only" content="independent-shell-witness">'
    assert before.count(b"</head>") == 1 and marker not in before and current_block != old_block
    parent_page = before.replace(b"</head>", marker+b"\n</head>")+old_block+after
    (FIX/"index.html").write_bytes(parent_page)
    fgit("stage-parent", "add", "-A")
    fgit("commit-parent", "commit", "-m", "A4 isolated parent with November 27 data and shell witness")
    assert all(c["pass"] for c in source("source-local-old", 0, False).values())
    paths = git("diff", "--name-only", BASE+"^", BASE).decode().splitlines()
    assert len(paths) == 16 and "index.html" in paths
    for name in paths:
        (FIX/name).parent.mkdir(exist_ok=True,parents=True)
        if name == "index.html":
            shutil.copyfile(ROOT/name, FIX/name)
        else:
            (FIX/name).write_bytes(git("show", BASE+":"+name))
    fgit("stage-daily", "add", "--", *paths)
    fgit("commit-daily", "commit", "-m", "A4 replay November 28 release and fifteen historical daily objects")
    assert not fgit("daily-status", "status", "--porcelain")
    assert fgit("daily-paths", "diff", "--name-only", "HEAD^", "HEAD").decode().splitlines() == paths
    for p in paths:
        if p != "index.html":
            assert git("rev-parse", "HEAD:"+p, cwd=FIX) == git("rev-parse", BASE+":"+p)
    ci = source("source-ci-daily", 0)
    assert ci["official-data"]["paperCount"] == 43 and ci["write-scope"]["outOfScope"] == []
    assert all(ci["write-scope"][k] == [] for k in ("tracked", "untracked"))
    baseline = HERE/"prepared.html"
    prep("prepare-daily", baseline)
    pb, pd, pa = data_parts(git("show","HEAD^:index.html",cwd=FIX))
    cb, cd, ca = data_parts(git("show","HEAD:index.html",cwd=FIX))
    actual = normalize(baseline.read_bytes())
    assert actual == pb+cd+pa and actual != cb+cd+ca and marker in pb and marker not in cb
    save("baseline-oracle", dict(parent=git("rev-parse","HEAD^",cwd=FIX).decode().strip(),
        current=git("rev-parse","HEAD",cwd=FIX).decode().strip(), expected=digest(pb+cd+pa),
        prepared=digest(actual), currentAsBaseline=digest(cb+cd+ca), oldBlock=digest(pd),
        newBlock=digest(cd), parentWitnessInBaseline=marker in actual, parentWitnessInTarget=marker in cb+cd+ca,
        paths=paths, identicalNonHtmlBlobs=15))
    assert source("source-strict-daily", 1, False)["official-data"]["pass"] is False
    page = FIX/"index.html"
    backup = HERE/"restore-page.bin"
    shutil.copyfile(page, backup)
    for name, anchor, edit in [("bad-json", b'"briefing_date":"2026-11-28"', b'"briefing_date":!'),
                               ("bad-date", b'"briefing_date":"2026-11-28"', b'"briefing_date":"2026-02-30"')]:
        try:
            changed = backup.read_bytes()
            assert anchor in changed
            page.write_bytes(changed.replace(anchor, edit, 1))
            assert not source("source-ci-"+name, 1)["official-data"]["pass"]
        finally:
            shutil.copyfile(backup, page)
    feed = FIX/"feed.xml"
    feedcopy = HERE/"restore-feed.bin"
    shutil.copyfile(feed,feedcopy)
    try:
        feed.write_bytes(feedcopy.read_bytes()+b"\n<!-- A4 local delta -->\n")
        assert source("source-ci-dirty", 1)["write-scope"]["outOfScope"] == ["feed.xml"]
        fgit("stage-dirty-feed","add","--","feed.xml")
        shutil.copyfile(feedcopy, feed)
        assert source("source-ci-staged", 1)["write-scope"]["outOfScope"] == ["feed.xml"]
    finally:
        shutil.copyfile(feedcopy,feed)
        fgit("restore-private-index","add","--","feed.xml")
    assert not fgit("clean-after-negatives","status","--porcelain")

def sparse_day():
    # Keep today's official registries and app code, replay an actual two-paper issue.
    current = normalize((ROOT/"index.html").read_bytes())
    before, block, after = data_parts(current)
    small = data(git("show","7feecfa:index.html"))
    assert small["briefing_date"] == "2026-11-02" and len(small["papers"]) == 2
    current_data = data(current)
    for k in ("generated_at","briefing_date","funnel","papers"):
        current_data[k] = small[k]
    payload = json.dumps(current_data,ensure_ascii=False,separators=(",",":")).encode()
    newblock, count = re.subn(rb"(const SITE_DATA\s*=\s*)\{.*\}(\s*;)", lambda m:m[1]+payload+m[2],block,flags=re.S)
    assert count == 1
    (FIX/"index.html").write_bytes(before+newblock+after)
    fgit("stage-small","add","--","index.html")
    fgit("commit-small","commit","-m","A4 replay two genuine November 2 papers with current registries")
    assert not fgit("small-status","status","--porcelain")
    assert source("source-ci-small", 0)["official-data"]["paperCount"] == 2
    baseline = HERE/"prepared-small.html"
    prep("prepare-small", baseline)
    assert normalize(baseline.read_bytes()) == normalize((FIX/"index.html").read_bytes())
    save("small-oracle", dict(historicalCommit=git("rev-parse","7feecfa").decode().strip(),
        historicalDate=small["briefing_date"], paperCount=len(small["papers"]), replacedFields=["generated_at","briefing_date","funnel","papers"],
        shellBeforeSha256=digest(before+after), preparedEqualsTarget=True))
    return ux("ux-ci-small",FIX,"--base-html",baseline).returncode

if __name__ == "__main__":
    if sys.argv[1] == "fixture": make_fixture()
    elif sys.argv[1] == "daily-ux": sys.exit(ux("ux-ci-daily",FIX,"--base-html",HERE/"prepared.html").returncode)
    elif sys.argv[1] == "small": sys.exit(sparse_day())
