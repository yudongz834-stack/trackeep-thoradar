"""T1128-SMOOTH-A4 local evidence collector. Run from the supplied checkout."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import platform
import re
import shutil
import subprocess
import sys
import tempfile

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[3]
OUT = HERE / "evidence"
OUT.mkdir(exist_ok=True)
FIX = HERE / "private-repo"
BASE = "28131f314f92a05227fd5923607d717c426da2c5"
WF = ".github/workflows/deploy_oss.yml"
FILES = ["index.html", "sw.js", "sw-retire.js", WF, ".github/workflows/daily_thoradar.yml",
         "tests/aicls/lib.mjs", "tests/ux/ux_probe.mjs",
         *(p.relative_to(ROOT).as_posix() for p in sorted((ROOT / "tests/smooth").glob("*.mjs")))]
ENV = {k: os.environ[k] for k in ("PATH", "SystemRoot", "WINDIR", "COMSPEC", "PATHEXT", "TEMP",
       "TMP", "ProgramFiles", "ProgramFiles(x86)", "LOCALAPPDATA", "USERPROFILE", "SystemDrive")
       if k in os.environ}

def digest(b):
    return hashlib.sha256(b).hexdigest()

def save(name, record):
    (OUT / (name + ".json")).write_text(json.dumps(record, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")

def invoke(name, cmd, cwd=ROOT, extra=None):
    cmd = list(map(str, cmd))
    begin = datetime.datetime.now(datetime.timezone.utc)
    record = {"cwd": str(cwd), "argv": cmd, "startUtc": begin.isoformat(), "runs": 1, "seed": None}
    run = subprocess.run(cmd, cwd=cwd, env={**ENV, **(extra or {})}, capture_output=True)
    for ext, raw in [("stdout", run.stdout), ("stderr", run.stderr)]:
        (OUT / f"{name}.{ext}.txt").write_bytes(raw)
    record.update(exit=run.returncode, endUtc=datetime.datetime.now(datetime.timezone.utc).isoformat())
    save(name + ".run", record)
    print(name, "exit", run.returncode, flush=True)
    return run

def check(name, cmd, cwd=ROOT):
    p = invoke(name, cmd, cwd)
    p.check_returncode()
    return p.stdout

def suite(name, kind, cwd=ROOT, *options):
    return invoke(name, ["node", f"tests/smooth/verify-{kind}.mjs", OUT / (name + ".json"), *options], cwd)

def git(*args, cwd=ROOT):
    return subprocess.check_output(["git", *args], cwd=cwd, env=ENV)

def data_parts(page):
    m = re.search(rb"/\*__THORADAR_DATA_START__\*/(.*?)/\*__THORADAR_DATA_END__\*/", page, re.S)
    assert m and page.count(m[0]) == 1
    return page[:m.start()], m[0], page[m.end():]

def normalize(page):
    return page.replace(b"\r\n", b"\n")

def data(page):
    return json.loads(re.search(rb"const SITE_DATA\s*=\s*(\{.*\})\s*;", data_parts(page)[1], re.S)[1])

def capture(label):
    hashes = {name: digest((ROOT / name).read_bytes()) for name in FILES}
    report = data((ROOT / "index.html").read_bytes())
    record = dict(hashes=hashes, head=git("rev-parse", "HEAD").decode().strip(),
                  briefingDate=report["briefing_date"], count=len(report["papers"]), platform=platform.platform(),
                  node=check(label+"-node", ["node", "-v"]).decode().strip(),
                  git=check(label+"-git", ["git", "--version"]).decode().strip(),
                  python=platform.python_version(), chrome=check(label+"-chrome", ["pwsh","-NoProfile","-Command",
                  "(Get-Item 'C:/Program Files/Google/Chrome/Application/chrome.exe').VersionInfo.ProductVersion"]).decode().strip())
    save(label, record)
    print(json.dumps(record, ensure_ascii=True))
    assert record["head"] == BASE and (record["briefingDate"], record["count"]) == ("2026-11-28", 43)
    assert list(hashes.values())[:3] == ["27ba018a9a3b4936ec734820af8cb505262bd55f41ae382047615f0a58d7c706",
          "e882e9e2eef0bf36781b8b03ecec23eb81221fa8b33272cdc9de3e368f76394f",
          "5ae38f2ba965f4e1b1d340da2ba5fadd8b58af82a1e271a02ddff97ab5686199"]

def deploy(name):
    switches = {"deploy-no-md5": (b" || md5 != expected", b""),
        "deploy-retire-wrong": (b"then active_worker=sw-retire.js;", b"then active_worker=sw.js;")}
    if name not in switches:
        return suite(name, "deploy")
    path = OUT / (name + ".yml")
    original = (ROOT / WF).read_bytes()
    before, after = switches[name]
    assert original.count(before) == 1
    path.write_bytes(original.replace(before, after))
    return suite(name, "deploy", ROOT, path)

def ux(name, cwd, *args):
    work = Path(tempfile.mkdtemp(prefix="a4-ux-")).resolve()
    try:
        result = invoke(name, ["node", "tests/ux/ux_probe.mjs", "--target", "index.html",
                               *args, "--label", name], cwd, {"XREV_SCRATCH":str(work)})
        source = work / ("out-" + name)
        if source.is_dir():
            shutil.copytree(source, OUT / (name + "-measurements"))
        return result
    finally:
        assert work.parent == Path(tempfile.gettempdir()).resolve() and work.name.startswith("a4-ux-")
        if not list(work.glob("ux-harness-*/profile")):
            shutil.rmtree(work)

if __name__ == "__main__":
    name = sys.argv[1]
    if name.startswith("inventory-"): capture(name)
    elif name.startswith("deploy"): sys.exit(deploy(name).returncode)
    elif name == "ux-local": sys.exit(ux(name, ROOT, "--base", BASE).returncode)
    else: sys.exit(suite(name, name.split("-")[0], ROOT, *sys.argv[2:]).returncode)
