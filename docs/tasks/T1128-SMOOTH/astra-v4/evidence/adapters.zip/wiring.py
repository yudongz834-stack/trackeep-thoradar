"""Inspect the real workflow structure and local publish trace with an independent oracle."""
import json
import base64
import hashlib
import re
import yaml
from run import OUT, ROOT, WF

workflow = yaml.load((ROOT / WF).read_text(encoding="utf-8"), Loader=yaml.BaseLoader)
verify = workflow["jobs"]["smooth-verify"]
deploy = workflow["jobs"]["deploy-oss"]
for job in (verify, deploy):
    assert "continue-on-error" not in job
    assert all("if" not in s and "continue-on-error" not in s for s in job["steps"])
refs = [job["steps"][0]["with"]["ref"] for job in (verify, deploy)]
expected_ref = "$" + "{{ github.sha }}"
assert refs == [expected_ref, expected_ref]
assert deploy["needs"] == "smooth-verify" and "if" not in deploy
commands = [s["run"] for s in verify["steps"] if "run" in s]
scripts = [re.search(r"node (\S+\.mjs)", s)[1] for s in commands]
assert scripts == ["tests/smooth/verify-"+k+".mjs" for k in ("deploy","source","s1","s2","s3")] + [
    "tests/smooth/prepare-ci-ux-baseline.mjs", "tests/ux/ux_probe.mjs"]
assert "--ci" in commands[1] and "--base-html" in commands[-1]
assert not any(" --only" in s or "--no-judge" in s for s in commands)
print(json.dumps(dict(trigger=workflow["on"], condition=verify["if"], refs=refs, needs=deploy["needs"],
    steps=scripts, shellGate="no step condition or continue-on-error", yaml=yaml.__version__)))

trace = json.loads((OUT / "deploy.json").read_text(encoding="utf-8"))
for label, worker in [("healthy", "sw.js"), ("healthy-retire", "sw-retire.js")]:
    sim = trace["simulations"][label]
    uploads = [c["args"] for c in sim["calls"] if c["tool"]=="ossutil" and c["args"][0]=="cp"]
    checks = {}
    for line in sim["stdout"].splitlines():
        match = re.match(r"Verified (\S+) HTTP=(\d+) Content-MD5=(\S+) expected=(\S+) MIME=(\S+) Cache-Control=(.*)",line)
        if not match: continue
        url, status, md5, expected, mime, cache = match.groups()
        source = worker if url.endswith("/sw.js") else "sw-retire.js" if url.endswith("/sw-retire.js") else "index.html"
        local = base64.b64encode(hashlib.md5((ROOT/source).read_bytes()).digest()).decode()
        assert status == "200" and md5 == expected == local
        if source.endswith(".js"):
            assert "javascript" in mime.lower() and "no-store" in cache.lower()
        checks[url] = dict(source=source, md5=local)
    urls = ["https://"+d+p for d in ("thoradar.online","www.thoradar.online") for p in ("/","/index.html","/sw.js","/sw-retire.js")]
    assert list(checks) == urls
    assert [c["args"][-1] for c in sim["calls"] if c["tool"]=="aliyun"] == ["\n".join(urls)]
    assert uploads[-2][-2:] == [worker,"oss://thoradar-online/sw.js"] and uploads[-1][-2]=="index.html"
    print(json.dumps(dict(mode=label, uploads=uploads[-3:], checks=checks)))
